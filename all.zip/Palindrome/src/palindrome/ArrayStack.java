/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindrome;

import java.util.Stack;

/**
 *
 * @author ejkpa
 */
public class ArrayStack {
   public static int capacity;
   private int top=-1;
   private Object Arr[];
   public ArrayStack(int c){
       Arr= new Object[c];
   }
   public boolean isEmpty(){
       return (top<0);
   }
   public void push(Object v){
       Arr[++top]=v;
   }
   public Object pop(){
       try{
           if(this.isEmpty()){
               throw new Exception();
           }else{
               return Arr[top--];
           }
       }
       catch(Exception e){
           System.out.println("Error Occured!");
           return null;
       }
      // return Arr[top-
   }
}
