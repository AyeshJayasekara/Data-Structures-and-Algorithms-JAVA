/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package palindrome;

import java.util.Stack;

/**
 *
 * @author ejkpa
 */
public class Palindrome {

    
    public static void main(String[] args) {
        ArrayStack obj = new ArrayStack(10);
        int i=8;
        obj.push(8);
        System.out.println(""+obj.isEmpty());
        i=(int)obj.pop()+1;
        System.out.println(""+i);
        System.out.println(""+obj.pop());
    }
    
}
