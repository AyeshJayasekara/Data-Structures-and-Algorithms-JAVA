package quicksort;

public class QuickSort {

	
	public static void main(String[] args) {
                QSort obj = new QSort(10);
                
                obj.printArray();
                obj.Startsort();
                System.out.println("");
                obj.printArray();
		
	}
	
	

}
